from pathlib import Path
import joblib
import streamlit as st
import pandas as pd


BASE = Path(__file__).resolve().parent


@st.cache_resource
def load_model():
    model_path = BASE / 'plots' / 'model' / 'logreg_pipeline.joblib'
    if not model_path.exists():
        return None
    return joblib.load(model_path)


def main():
    st.title('Titanic Survival Predictor')
    st.write('Provide passenger information to predict survival probability.')

    model = load_model()
    if model is None:
        st.error('Trained model not found. Run eda/model_titanic.py to train and save the pipeline at eda/plots/model/logreg_pipeline.joblib')
        return

    st.sidebar.header('Passenger features')
    pclass = st.sidebar.selectbox('Pclass', options=[1, 2, 3], index=2)
    sex = st.sidebar.selectbox('Sex', options=['male', 'female'], index=0)
    age = st.sidebar.slider('Age', min_value=0.0, max_value=100.0, value=30.0)
    sibsp = st.sidebar.number_input('SibSp', min_value=0, max_value=10, value=0)
    parch = st.sidebar.number_input('Parch', min_value=0, max_value=10, value=0)
    fare = st.sidebar.number_input('Fare', min_value=0.0, max_value=1000.0, value=14.45)
    embarked = st.sidebar.selectbox('Embarked', options=['S', 'C', 'Q'], index=0)
    title = st.sidebar.selectbox('Title', options=['Mr', 'Mrs', 'Miss', 'Master', 'Rare'], index=0)
    deck = st.sidebar.selectbox('Deck (M=missing)', options=['M', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'T'], index=0)

    input_df = pd.DataFrame([{
        'Pclass': pclass,
        'Sex': sex,
        'Age': age,
        'SibSp': sibsp,
        'Parch': parch,
        'Fare': fare,
        'Embarked': embarked,
        'Title': title,
        'Deck': deck,
        'FamilySize': sibsp + parch + 1
    }])

    if st.button('Predict Survival'):
        try:
            proba = model.predict_proba(input_df)[:, 1][0]
            pred = model.predict(input_df)[0]
            st.write(f'Predicted survival probability: {proba:.3f}')
            st.write('Predicted class:', 'Survived' if pred == 1 else 'Not survived')
        except Exception as e:
            st.error(f'Prediction failed: {e}')


if __name__ == '__main__':
    main()
